import form.main
import soar
import soar.application
form.main.Application(soar.application.application)
