============
Libdw
============

Libdw is a library used in teaching Digital World at SUTD. It provides some utilies and tools to connect to Amigobot.

INSTALLATION
============

Linux and Mac OS X
------------------

1. Open terminal
2. Unzip package libdw.tar.gz
3. Type: $ sudo python setup install

Windows
-------

1. Unzip package libdw.tar.gz
2. Open Command Prompt
3. type: $ python setup install
