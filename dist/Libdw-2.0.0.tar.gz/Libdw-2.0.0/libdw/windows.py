# A place to remember some global state about windows inside a soar program.

windowList = []
