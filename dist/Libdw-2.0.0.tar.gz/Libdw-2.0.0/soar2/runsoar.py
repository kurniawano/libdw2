import form.main
import soar2
import soar2.application
form.main.Application(soar2.application.application)
